import Posts from "./component/Posts";

function App() {
  return (
    <div className="App">
      <>
      <Posts />
      </>
    </div>
  );
}

export default App;
