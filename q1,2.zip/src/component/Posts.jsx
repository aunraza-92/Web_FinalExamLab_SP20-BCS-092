import React, { useState, useEffect } from 'react';

function Posts() {
  const [posts, setPosts] = useState([]);
  const [total, setTotal] = useState(0);
  const [skip, setSkip] = useState(0);
  const [limit, setLimit] = useState(10);

  useEffect(() => {
    const fetchData = async () => {
      const res = await fetch(`https://dummyjson.com/posts?limit=${limit}&skip=${skip}`);
      const data = await res.json();
      setPosts(data.posts);
      setTotal(data.total);
    };
    fetchData();
  }, [skip, limit]);

  const handlePrevClick = () => {
    if (skip > 0) {
      setSkip(skip - limit);
    }
  };

  const handleNextClick = () => {
    if (skip + limit < total) {
      setSkip(skip + limit);
    }
  };

  return (
    <div>
      <button onClick={handlePrevClick} disabled={skip === 0}>Prev</button>
      <button onClick={handleNextClick} disabled={skip + limit >= total}>Next</button>
      <div>
        {posts.map(post => (
          <div key={post.id}>
            <h2>{post.title}</h2>
            <p>Reactions: {post.reactions}</p>
            <p>User ID: {post.userId}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Posts;