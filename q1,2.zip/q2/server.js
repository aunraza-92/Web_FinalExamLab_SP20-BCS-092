const express = require('express');
const mongoose = require('mongoose');
const postRoute = require("./route/posts");
const app = express();

mongoose.set('strictQuery', false);
mongoose
.connect("mongodb://127.0.0.1:27017/q2")
.then(console.log("Connected to MongoDB"))
.catch((err)=>console.log(err));


app.use("/api/posts", postRoute);

app.listen(5000, () => {
    console.log('Server started on port 5000');
});